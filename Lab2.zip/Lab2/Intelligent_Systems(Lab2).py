import matplotlib.pyplot as plt
import heapq
import pandas as pd
import numpy as np

df = pd.read_csv("/home/rvill/Rolly/Intelligent Systems/Python/Lab2/us_tile_grid.csv")

print(df)

rows = df["row"].max() + 1
cols = df["column"].max() + 1

# Make grid (0 = walkable, 1 = empty/no state)
grid = np.ones((rows, cols))
for _, r in df.iterrows():
    grid[r["row"], r["column"]] = 0

# --- A* Algorithm ---
def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])
    
def manhattan(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def euclidean(a, b):
    return ((a[0] - b[0])**2 + (a[1] - b[1])**2) ** 0.5

def zero(a, b):  # like Dijkstra (no heuristic)
    return 0

def dijkstra(array, start, goal):
    return astar(array, start, goal, heuristic=zero)

def greedy_bfs(array, start, goal):
    return astar(array, start, goal, heuristic=lambda a,b: manhattan(a,b)*1000)


def astar(array, start, goal, heuristic):
    neighbors = [(0,1),(0,-1),(1,0),(-1,0)]
    close_set = set()
    came_from = {}
    gscore = {start:0}
    fscore = {start:heuristic(start, goal)}
    oheap = []
    heapq.heappush(oheap, (fscore[start], start))

    explored = []  # track explored

    while oheap:
        current = heapq.heappop(oheap)[1]
        explored.append(current)

        if current == goal:
            data = []
            while current in came_from:
                data.append(current)
                current = came_from[current]
            return data[::-1], explored

        close_set.add(current)
        for i, j in neighbors:
            neighbor = (current[0]+i, current[1]+j)
            tentative_g_score = gscore[current] + 1
            if 0 <= neighbor[0] < array.shape[0]:
                if 0 <= neighbor[1] < array.shape[1]:
                    if array[neighbor[0]][neighbor[1]] == 1:
                        continue
                else:
                    continue
            else:
                continue

            if neighbor in close_set and tentative_g_score >= gscore.get(neighbor, 9999):
                continue

            if tentative_g_score < gscore.get(neighbor, 9999):
                came_from[neighbor] = current
                gscore[neighbor] = tentative_g_score
                fscore[neighbor] = tentative_g_score + heuristic(neighbor, goal)
                heapq.heappush(oheap, (fscore[neighbor], neighbor))

    return False, explored

# --- Example Start and Goal ---
start_state = "CA"
goal_state = "NY"

start = tuple(df.loc[df["code"] == start_state, ["row","column"]].values[0])
goal = tuple(df.loc[df["code"] == goal_state, ["row","column"]].values[0])

# path = astar(grid, start, goal)
path_manhattan = astar(grid, start, goal, heuristic=manhattan)
path_euclidean = astar(grid, start, goal, heuristic=euclidean)
path_zero = astar(grid, start, goal, heuristic=zero)  # equivalent to Dijkstra

path, explored = astar(grid, start, goal, heuristic=manhattan)

plt.imshow(grid, cmap="gray_r")

# explored nodes
explored_x, explored_y = zip(*explored)
plt.scatter(explored_y, explored_x, c="lightblue", s=30, label="Explored")

# path
if path:
    path_x, path_y = zip(*path)
    plt.plot(path_y, path_x, marker="o", color="red", label="Path")

# start & goal
plt.plot(start[1], start[0], "go", label="Start")
plt.plot(goal[1], goal[0], "bo", label="Goal")

plt.legend()
plt.title("A* Pathfinding with Explored Nodes")
plt.gca().invert_yaxis()
plt.show()


# --- Visualization ---
plt.imshow(grid, cmap="gray_r")

# plot states
for _, r in df.iterrows():
    plt.text(r["column"], r["row"], r["code"], ha="center", va="center", fontsize=8)

# plot path
if path:
    path_x, path_y = zip(*path)
    plt.plot(path_y, path_x, marker="o", color="red")

plt.plot(start[1], start[0], "go", label="Start")
plt.plot(goal[1], goal[0], "bo", label="Goal")
plt.legend()
plt.title(f"A* Pathfinding: {start_state} → {goal_state}")
plt.gca().invert_yaxis()
plt.show()
